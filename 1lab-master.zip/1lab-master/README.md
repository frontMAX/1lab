                                         SKIDBERGET

Laboration 1, där uppgiften är att göra en textbaserad interaktiv upplevelse. 
Där jag har valt att gör en liten resa över ett skidberg, det kommer finnas 3st vägval. 
En slut destination finns och dit ska man komma genom att välja någon av dessa vägval.

Jag har valt att ge information till användaren genom text på varje steg och att man gör sitt val genom att klicka på en knapp för att ta sig dit man vill. 
 


DEMO { https://frontmax.github.io/1lab/ }



Max Andersson